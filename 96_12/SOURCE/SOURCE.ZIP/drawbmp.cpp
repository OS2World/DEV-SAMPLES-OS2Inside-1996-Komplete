Boolean SJBitmap::drawBitmap(
           unsigned long status, 
           IGraphicContext& gc, 
           IRectangle targetRect)
{
  IPoint sourceBL;
  IPoint sourceTR;
  if (!iBitmapPtr)
    return false;
  // calculate the position from the status: 
  // 0xFF has the y translation and
  // 0xFF00 has the x translation 
  // use picture size for factor
  sourceBL = IPoint(((status & 0xFF00) >> 16)
                    *iPictureSize.width(),
                    (status & 0xFF)
                    *iPictureSize.height());
  sourceTR = (IPoint)(sourceBL+iPictureSize);
  if (iBitmapTemplatePtr){
    // OR the template
    iBitmapTemplatePtr->
      drawOn(gc, 
             targetRect.minXMinY(), 
             targetRect.maxXMaxY(),
             sourceBL,sourceTR,
             IGBitmap::sourceAnd);
  // AND the bitmap itself
    iBitmapPtr->
      drawOn(gc, 
             targetRect.minXMinY(), 
             targetRect.maxXMaxY(),
             sourceBL,sourceTR,
             IGBitmap::sourcePaint);
  }
  else{
    // no template: draw normal 
    iBitmapPtr->
      drawOn(gc, 
             targetRect.minXMinY(), 
             targetRect.maxXMaxY(),
             sourceBL,sourceTR,
             IGBitmap::normal);
  }
  return true;
}