void SJField::animateMove(IPoint source, 
                          IPoint direction, 
                          SJBitmap* pBitmap, 
                          int status)
{
  int n;
  IPresSpaceHandle canvasPS;
  IGraphicContext *canvasGC;
  IGraphicContext *gc;
  IPoint moveOffset(0,0), oldMoveOffset(0,0);
  IRectangle paintRect(squareRect(source));
  IRectangle updateRect;
  IRectangle 
    startRect(IPoint(0,0),(ISize)(paintRect.size()
                                  -ISize(1,1)));
  IRectangle 
    copyRect(0,0,
             (abs(direction.x())+1)
             *iSquareSize.width(),
             (abs(direction.y())+1)
             *iSquareSize.height());
  IPoint offset(squareRect(source).minXMinY());
  IPoint canvasOffset;
  drawBackground(source);  // restore background 
  // if there can be more than one items you
  // have to use drawSquares here!
  IGBitmap fieldBitmap(*iGC,fieldRect().
                       movedTo(IPoint(0,0)));
  gc = new IGraphicContext(copyRect.size());
  canvasPS = SJGlobal::canvas()->presSpace();
  canvasGC = new IGraphicContext(canvasPS);
  if(direction.x() < 0){
    offset+=(IPoint(iSquareSize.width()
                    *direction.x(),0));
    startRect.moveBy(IPoint(iSquareSize.width()
                            *direction.x()
                            *(-1),0));
  }
  if(direction.y() < 0){
    startRect.moveBy(IPoint(0,iSquareSize.height()
                            *direction.y()*(-1)));
    offset+=(IPoint(0,iSquareSize.height()
                    *direction.y()));
  }
  canvasOffset = offset + iFieldOrigin;
  for(n=1;n<=8;n++){
    oldMoveOffset = moveOffset; // old area
    moveOffset.setX(direction.x()
                    *iSquareSize.width()*n/8);
    moveOffset.setY(direction.y()
                    *iSquareSize.height()*n/8);
    paintRect = startRect.movedBy(moveOffset);
    updateRect = paintRect 
      | startRect.movedBy(oldMoveOffset);
    fieldBitmap.drawOn(*gc,IPoint(0,0),
                       copyRect.maxXMaxY(),
                       offset,
                       offset+copyRect.
                         maxXMaxY());
    pBitmap->drawBitmap(status,*gc,paintRect);
    IGBitmap tempBitmap(*gc,copyRect);
    tempBitmap.
      drawOn(*canvasGC,
             canvasOffset+updateRect.minXMinY(),
             canvasOffset+updateRect.maxXMaxY(),
             updateRect.minXMinY(),
             updateRect.maxXMaxY());
  }
  SJGlobal::canvas()->releasePresSpace(canvasPS);
  delete gc;
  delete canvasGC;
}