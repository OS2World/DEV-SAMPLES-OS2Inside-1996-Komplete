IRectangle SJField::adjustSize(
                       ISize canvasSize)
{
  iSquareSize = ISize();
  long width, height;
  if ((iSize.width() <= 0) ||
      (iSize.height() <= 0))
    return IRectangle();   // zero size...
  if (!SJGlobal::canvas())	
    return IRectangle();   // no canvas...
  if (canvasSize == ISize())
    canvasSize = SJGlobal::canvas()->size();
  if ((canvasSize.width() <= 0) || 
      (canvasSize.height() <= 0))
    return IRectangle();   // zero size...
  // now divide the canvas size by the sqaures
  width = canvasSize.width() / iSize.width();
  height = canvasSize.height() / iSize.height();
  // we want squares => width  == height
  width = (width < height) ? width : height;
  // now let's set the new size for one square
  iSquareSize = ISize(width,width);
  // ... and calculate the origin by checking 
  // the difference between the field size and
  // the canvas size - so the field is centered
  iFieldOrigin =
   IPoint((canvasSize.width()-
           width*iSize.width())/2,
          (canvasSize.height()-
           width*iSize.height())/2);
  if (iGC)
    delete iGC;
  iGC = new IGraphicContext(fieldRect().size());
  return fieldRect();
}