Boolean SJField::paintWindow(IPaintEvent     
                     &paintEvent)
{
  IGBitmap fieldBitmap(*iGC,
   fieldRect().movedTo(IPoint(0,0)));
  IGRectangle gRect;
  if (!iGC)
    return false;
  IGraphicContext
   gc(paintEvent.presSpaceHandle());    
  gRect.setEnclosingRect(
    paintEvent.rect());
  gRect.drawOn(gc);				    
  fieldBitmap.moveTo(iFieldOrigin);
  fieldBitmap.drawOn(gc);
  return true;
}