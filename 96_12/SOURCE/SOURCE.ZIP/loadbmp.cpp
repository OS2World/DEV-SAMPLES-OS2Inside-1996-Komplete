Boolean
 SJModules::activateGraphicsLibrary( 
              colorDepth aColorDepth, 
              graphFormat aGraphFormat)
{
  // clean up if already activated:
  IString DLLName;
  if (iGraphicsDLLPtr){
    iGraphicsDLLPtr->close();
    delete iGraphicsDLLPtr;
    iGraphicsDLLPtr = NULL;	
  }
  // check the color depth
  switch(aColorDepth){ 
  case colors256:
    DLLName = IString("sj256");
    break;
  case hicolor:
    DLLName = IString("sjhi");
    break;
  default:
    return false;	// don't load library
  }
  // check the graphics format:
  switch(aGraphFormat){	
  case format64:		
    // set base size of one picture    
    iGraphicsBaseSize = 64;	
    DLLName+=IString("f64");
    break;
  default:
    iGraphicsBaseSize = 0;
    return false; // don't load library
  }
  try{
   iGraphicsDLLPtr = 
     new IDynamicLinkLibrary(DLLName);
  }
  catch(IAccessError &ia){
    // handle the exception
    return false;
  }
  return true;
}